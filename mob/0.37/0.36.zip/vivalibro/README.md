# Viva Libro App 
- new book created with SERPAPI utilizing Google Lens
- PWA of my library 


# API 
[GET]
- https://vivalibro.com:3002/ma/lib/id/[libid] ### for 10 first books
- https://vivalibro.com:3002/ma/lib/q/Νίκος  # for search 
-  ###login

[POST]
- ###delete 
- ###new 
