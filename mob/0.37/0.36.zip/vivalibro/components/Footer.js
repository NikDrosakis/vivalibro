// Footer.js
import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
const Footer = ({ navigation }) => {

  
  const handleLogout = async () => {
    await AsyncStorage.removeItem('GSID');
    await AsyncStorage.removeItem('GSGRP');
    await AsyncStorage.removeItem('GSLIBID');
    navigation.navigate('Login');
  };

  return (
    <View style={styles.bottomMenu}>
      <TouchableOpacity style={styles.menuButton} onPress={() => navigation.navigate('Book')}>
        <Ionicons name="book" size={30} color="black" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.menuButton} onPress={() => navigation.navigate('Search')}>
        <Ionicons name="search" size={30} color="black" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.menuButton} onPress={() => navigation.navigate('Settings')}>
        <Ionicons name="settings" size={30} color="black" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.menuButton} onPress={() => navigation.navigate('Profile')}>
        <Ionicons name="person" size={30} color="black" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.menuButton} onPress={() => navigation.navigate('Documentation')}>
        <Ionicons name="help-buoy" size={30} color="black" />
      </TouchableOpacity>
            <TouchableOpacity style={styles.menuButton} onPress={handleLogout}>
        <Ionicons name="log-out-outline" size={30} color="black" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  bottomMenu: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 50,
    backgroundColor: '#eee',
    borderTopWidth: 1,
    borderTopColor: '#ccc',
  },
  menuButton: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
});

export default Footer;
